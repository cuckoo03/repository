package com.twitter

import groovy.transform.TypeChecked

import org.apache.log4j.Logger

@TypeChecked
class SnsAuthHttp {
	private Logger LOG = Logger.getLogger(SnsAuthHttp.class)
	static main(args) {
	}
}
